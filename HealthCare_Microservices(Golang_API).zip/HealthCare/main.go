package main

import (
	"log"

	repository "./repository" // Contains Database connection details
	router "./router"
)

//"./router")

func main() {

	// Initialize database
	log.Println("Initializing DB")

	db := repository.InitDB()

	// Closing DB in the end of program
	defer db.Close()

	router.InitServer()
}

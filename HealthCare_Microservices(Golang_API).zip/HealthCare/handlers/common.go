package handlers

import (
	"encoding/json"
	"io"
	"net/http"
)

func respondSucess(w http.ResponseWriter, statusCode int, responseData interface{}) {
	//Add DB logs here
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	responseDataByte, err := responseData.([]byte)

	if !err {
		w.Write(responseDataByte)
	}

	json.NewEncoder(w).Encode(responseData)
}

// func respondHTML(w http.ResponseWriter, statusCode int, responseData string) {
// 	//Add DB logs here
// 	w.Header().Set("Content-Type","application/html")
// 	w.WriteHeader(statusCode)
// 	w.Write([]byte(responseData))
// }

func respondError(w http.ResponseWriter, statusCode int, responseData interface{}) {
	//Add DB logs here
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(responseData)
}

//parseJSONPayload - target should be pointer
func parseJSONPayload(w http.ResponseWriter, r *http.Request, target interface{}) error {
	if err := json.NewDecoder(r.Body).Decode(target); err != nil && err != io.EOF {
		respondError(w, http.StatusBadRequest, "Check your payload, may have some mismatched key(s) or data type(s).")
		return err
	}
	return nil
}

package handlers

import (
	"log"
	"net/http"

	models "../models"
	repository "../repository"
)

//////////////////////////////////////////////   CREATE ENROLLEE ///////////////////////////////////////////
func CreateEnrollee(w http.ResponseWriter, r *http.Request) {

	// Creating varible 'request' for capturing parsed resquest
	var request models.CreateEnrolleeRequestBody

	if err := parseJSONPayload(w, r, &request); err != nil {
		log.Printf("Create Enrollee error %v", err)
		return
	}

	var message []string // nil slice

	if request.Name == "" {
		Name := "Enrollees_Name is missing from the Json request."
		message = append(message, Name)
	}
	if request.ID == 0 {
		id := "Enrollees_id is missing from the Json request."
		message = append(message, id)
	}
	if request.ActivationStatus == nil {
		status := "Activation_status is missing from the Json request."
		message = append(message, status)
	}
	if request.Birthdate == "" {
		date := "Birth_Date is missing from the Json request."
		message = append(message, date)
	}
	if message != nil {
		respondError(w, http.StatusBadRequest, message)
		return
	}

	create_enrollee, erro := repository.CreateEnrollee(request)
	if erro != nil {
		log.Printf("Create Enrollee error %v", erro)
		respondError(w, http.StatusInternalServerError, erro)
		return
	}

	//empty struct
	var response models.CreateEnrolleeResponseBody

	//Comparing Empty Struct
	if create_enrollee == response {
		text := []string{"There is some error with query."}
		respondError(w, http.StatusInternalServerError, text)
		return
	}

	respondSucess(w, http.StatusOK, create_enrollee)
}

////////////////////////////////// MODIFY ENROLLEE /////////////////////////////////////////////////////
func UpdateEnrollee(w http.ResponseWriter, r *http.Request) {

	// Creating varible 'request' for capturing parsed resquest
	var request models.ModifyEnrolleeRequestBody

	if err := parseJSONPayload(w, r, &request); err != nil {
		log.Printf("Modify Enrollee error %v", err)
		return
	}

	//Checking status for Enrollees_id
	if request.ID == 0 {
		text := []string{"Enrollees_Id is missing from the Json request."}
		//id = "Enrollees_id is missing from the Json request."
		respondError(w, http.StatusBadRequest, text)
		return
	}

	modify_enrollee, erro := repository.UpdateEnrollee(request)
	if erro != nil {
		log.Printf("Modify Enrollee error %v", erro)
		respondError(w, http.StatusInternalServerError, erro)
		return
	}
	if modify_enrollee == "" {
		text := map[string]string{"Result": "Please provide valide 'Enrollees_Id'."}
		respondError(w, http.StatusBadRequest, text)
		return
	}

	repo_response := map[string]string{"Result": modify_enrollee}
	respondSucess(w, http.StatusOK, repo_response)
}

////////////////////////////////// DELETE ENROLLEE /////////////////////////////////////////////////////
func DeleteEnrollee(w http.ResponseWriter, r *http.Request) {

	// Creating varible 'request' for capturing parsed resquest
	var request models.DeleteEnrolleeRequestBody

	if err := parseJSONPayload(w, r, &request); err != nil {
		log.Printf("Delete Enrollee error %v", err)
		return
	}

	//Checking status for Enrollees_Id
	if request.ID == 0 {
		text := []string{"Enrollees_Id is missing from the Json request."}
		//id = "Enrollees_id is missing from the Json request."
		respondError(w, http.StatusBadRequest, text)
		return
	}

	delete_enrollee, erro := repository.DeleteEnrollee(request)
	if erro != nil {
		log.Printf("Delete Enrollee error %v", erro)
		respondError(w, http.StatusInternalServerError, erro)
		return
	}

	if delete_enrollee == "" {
		text := map[string]string{"Result": "Please provide valide 'Enrollees_Id'."}
		respondError(w, http.StatusBadRequest, text)
		return
	}
	repo_response := map[string]string{"Result": delete_enrollee}
	respondSucess(w, http.StatusOK, repo_response)
}

//////////////////////////////////////////////   CREATE ENROLLEE DEPENDENT  ///////////////////////////////////////////
func CreateEnrolleeDependent(w http.ResponseWriter, r *http.Request) {

	// Creating varible 'request' for capturing parsed resquest
	var request models.CreateEnrolleeDependentRequestBody

	if err := parseJSONPayload(w, r, &request); err != nil {
		log.Printf("Create Enrollee Dependent error %v", err)
		return
	}

	var message []string // nil slice

	if request.ID == 0 {
		id := "Dependent_Id is missing from the Json request."
		message = append(message, id)
	}
	if request.DependentName == "" {
		Name := "Dependent_Name is missing from the Json request."
		message = append(message, Name)
	}
	if request.Birthdate == "" {
		date := "Birth_Date is missing from the Json request."
		message = append(message, date)
	}
	if message != nil {
		respondError(w, http.StatusBadRequest, message)
		return
	}

	create_dependent, erro := repository.CreateEnrolleeDependent(request)
	if erro != nil {
		log.Printf("Create Dependent error %v", erro)
		respondError(w, http.StatusInternalServerError, erro)
		return
	}

	//empty struct
	var response models.CreateEnrolleeDependentResponseBody

	//Comparing Empty Struct
	if create_dependent == response {
		text := []string{"There is some error with query."}
		respondError(w, http.StatusInternalServerError, text)
		return
	}

	respondSucess(w, http.StatusOK, create_dependent)
}

////////////////////////////////// MODIFY ENROLLEE Dependent /////////////////////////////////////////////////////
func UpdateEnrolleeDependent(w http.ResponseWriter, r *http.Request) {

	// Creating varible 'request' for capturing parsed request
	var request models.ModifyEnrolleeDependentRequestBody

	if err := parseJSONPayload(w, r, &request); err != nil {
		log.Printf("Modify Dependent error %v", err)
		return
	}

	//Checking status for Enrollees_Id
	if request.ID == 0 {
		text := []string{"Dependent_Id is missing from the Json request."}
		respondError(w, http.StatusBadRequest, text)
		return
	}

	modify_dependent, erro := repository.UpdateEnrolleeDependent(request)
	if erro != nil {
		log.Printf("Modify Dependent error %v", erro)
		respondError(w, http.StatusInternalServerError, erro)
		return
	}
	if modify_dependent == "" {
		text := map[string]string{"Result": "Please provide valide 'Dependent_Id'."}
		respondError(w, http.StatusBadRequest, text)
		return
	}

	repo_response := map[string]string{"Result": modify_dependent}
	respondSucess(w, http.StatusOK, repo_response)
}

////////////////////////////////// DELETE ENROLLEE DEPENDENT /////////////////////////////////////////////////////
func DeleteEnrolleeDependent(w http.ResponseWriter, r *http.Request) {

	// Creating varible 'request' for capturing parsed resquest
	var request models.DeleteEnrolleeDependentRequestBody

	if err := parseJSONPayload(w, r, &request); err != nil {
		log.Printf("Delete Dependent error %v", err)
		return
	}

	//Checking status for Dependent_Id
	if request.ID == 0 {
		text := []string{"'Dependent_Id' is missing from the Json request."}
		respondError(w, http.StatusBadRequest, text)
		return
	}

	delete_dependent, erro := repository.DeleteEnrolleeDependent(request)
	if erro != nil {
		log.Printf("Delete Dependent error %v", erro)
		respondError(w, http.StatusInternalServerError, erro)
		return
	}

	if delete_dependent == "" {
		text := map[string]string{"Result": "Please provide valide 'Dependent_Id'."}
		respondError(w, http.StatusBadRequest, text)
		return
	}
	repo_response := map[string]string{"Result": delete_dependent}
	respondSucess(w, http.StatusOK, repo_response)
}

package repository

import (
	"fmt"
	"log"

	models "../models"
)

/////////////////////////////////////////////// CREATE Enrollee ///////////////////////////////////////////
func CreateEnrollee(request models.CreateEnrolleeRequestBody) (models.CreateEnrolleeResponseBody, error) {

	var response models.CreateEnrolleeResponseBody

	// Inserting data into DB
	sql := fmt.Sprintf("INSERT INTO `Enrollees` SET Enrollees_Id = '%v', Enrollees_Name = '%s',Activation_Status = '%v',Birth_Date = '%s', Phone = '%v',Dependent_Name = '%s'", request.ID, request.Name, *request.ActivationStatus, request.Birthdate, request.Phone, request.Dependent)

	result, err := db.Query(sql)
	if err != nil {
		log.Println("err", err)
		return response, err
	}

	if result != nil {
		response.Result = "Enrollee has been added sucessfully."
	}

	return response, nil
}

///////////////////////////////////////////  MODIFY Enrollee  //////////////////////////////////////////
func UpdateEnrollee(request models.ModifyEnrolleeRequestBody) (string, error) {

	//Checking existance/valid Enrollees_id
	type valid struct {
		Enrollees_Id int
	}
	var val []valid // Creating valid struct type of slice

	// Fetching valid Enrollees_id from DB
	sql := fmt.Sprintf("SELECT `Enrollees_Id` FROM `Enrollees` WHERE `Enrollees_Id` = %v ", request.ID)
	res, erro := db.Query(sql)

	for res.Next() {
		var user valid
		res.Scan(&user.Enrollees_Id)
		val = append(val, user) // appending result into val slice
	}

	if erro != nil || val == nil {
		log.Println("Error in Enrollee Id", erro)
		return "", erro
	}

	// Updating data into DB
	sql_1 := fmt.Sprintf("UPDATE `Enrollees` SET Enrollees_Name = '%s', Activation_Status = '%v', Birth_Date = '%s', Phone = '%v',Dependent_Name = '%s' WHERE `Enrollees_Id` = %v", request.Name, request.ActivationStatus, request.Birthdate, request.Phone, request.Dependent, request.ID)
	result, err := db.Query(sql_1)
	if err != nil || result == nil {
		log.Println("err", err)
		return "", err
	}

	response := "Enrollee details updated sucessfully."
	return response, nil
}

///////////////////////////////////////////  DELETE Enrollee  //////////////////////////////////////////
func DeleteEnrollee(request models.DeleteEnrolleeRequestBody) (string, error) {

	//Checking existance/valid Enrollees_id
	type valid struct {
		Enrollees_id int
	}
	var val []valid // Creating valid struct type of slice

	// Fetching valid Enrollees_id from DB
	sql := fmt.Sprintf("SELECT `Enrollees_Id` FROM `Enrollees` WHERE `Enrollees_Id` = %v ", request.ID)
	res, erro := db.Query(sql)

	for res.Next() {
		var user valid
		res.Scan(&user.Enrollees_id)
		val = append(val, user) // appending result into val slice
	}

	if erro != nil || val == nil {
		log.Println("Error in Enrollee Id", erro)
		return "", erro
	}

	// Deleting Enrollee from DB
	sql_1 := fmt.Sprintf("DELETE FROM `Enrollees` WHERE `Enrollees_Id` = %v", request.ID)
	result, err := db.Query(sql_1)
	if err != nil || result == nil {
		log.Println("err", err)
		return "", err
	}

	response := "Enrollee deleted sucessfully."
	return response, nil
}

/////////////////////////////////////CREATE Enrollee Dependents ///////////////////////////////////////////
func CreateEnrolleeDependent(request models.CreateEnrolleeDependentRequestBody) (models.CreateEnrolleeDependentResponseBody, error) {

	var response models.CreateEnrolleeDependentResponseBody

	// Inserting data into DB
	sql := fmt.Sprintf("INSERT INTO `Enrollees_Dependents` SET Dependent_Id = '%v', Dependent_Name = '%s',Birth_Date = '%v'", request.ID, request.DependentName, request.Birthdate)
	fmt.Println(sql)

	result, err := db.Query(sql)
	if err != nil {
		log.Println("err", err)
		return response, err
	}

	if result != nil {
		response.Result = "Enrollee's Dependent added sucessfully."
	}

	return response, nil
}

///////////////////////////////////////////  MODIFY Enrollee Dependent //////////////////////////////////////////
func UpdateEnrolleeDependent(request models.ModifyEnrolleeDependentRequestBody) (string, error) {

	//Checking existance/valid Enrollees_id
	type valid struct {
		Dependent_id int
	}
	var val []valid // Creating valid struct type of slice

	// Fetching valid Enrollees_id from DB
	sql := fmt.Sprintf("SELECT `Dependent_Id` FROM `Enrollees_Dependents` WHERE `Dependent_Id` = %v ", request.ID)
	res, erro := db.Query(sql)

	for res.Next() {
		var user valid
		res.Scan(&user.Dependent_id)
		val = append(val, user) // appending result into val slice
	}

	if erro != nil || val == nil {
		log.Println("Error in Dependent Id", erro)
		return "", erro
	}

	// Updating data into DB
	sql_1 := fmt.Sprintf("UPDATE `Enrollees_Dependents` SET Dependent_Name = '%s', Birth_Date = '%s' WHERE `Dependent_Id` = %v", request.DependentName, request.Birthdate, request.ID)
	result, err := db.Query(sql_1)
	if err != nil || result == nil {
		log.Println("err", err)
		return "", err
	}

	response := "Dependent details updated sucessfully."
	return response, nil
}

///////////////////////////////////////////  DELETE Enrollee Dependent //////////////////////////////////////////
func DeleteEnrolleeDependent(request models.DeleteEnrolleeDependentRequestBody) (string, error) {

	//Checking existance/valid Enrollees_id
	type valid struct {
		Dependent_id int
	}
	var val []valid // Creating valid struct type of slice

	// Fetching valid Enrollees_id from DB
	sql := fmt.Sprintf("SELECT `Dependent_Id` FROM `Enrollees_Dependents` WHERE `Dependent_Id` = %v ", request.ID)
	res, erro := db.Query(sql)

	for res.Next() {
		var user valid
		res.Scan(&user.Dependent_id)
		val = append(val, user) // appending result into val slice
	}

	if erro != nil || val == nil {
		log.Println("Error in Dependent Id", erro)
		return "", erro
	}

	// Deleting Enrollee from DB
	sql_1 := fmt.Sprintf("DELETE FROM `Enrollees_Dependents` WHERE `Dependent_Id` = %v", request.ID)
	result, err := db.Query(sql_1)
	if err != nil || result == nil {
		log.Println("err", err)
		return "", err
	}

	response := "Dependent deleted sucessfully."
	return response, nil
}

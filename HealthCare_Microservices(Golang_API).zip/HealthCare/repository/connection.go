package repository

import (
	"database/sql"
	"fmt"
	"log"

	// mysql driver
	_ "../github.com/go-sql-driver/mysql"
)

var db *sql.DB

// InitDB initializes the database connection
func InitDB() *sql.DB {
	var err error

	// Passsing DB connection Details (using phpadmindb)
	username := "sql12363160"
	password := "emzILPfiUw"
	hostname := "sql12.freesqldatabase.com"
	dbname := "sql12363160"

	// Open the DB connection
	SQL := fmt.Sprintf("%s:%s@tcp(%s)/%s", username, password, hostname, dbname)
	db, err = sql.Open("mysql", SQL)

	if err != nil {
		fmt.Println("Error", err)
	}

	// Check for errors
	if err != nil {
		panic(err.Error())
	} else {
		createTables() // Calling internal function createTables() for creating tables
		log.Println("Starting..")
	}

	return db
}

func createTables() {
	db.Query("CREATE TABLE IF NOT EXISTS `Enrollees` ( `Enrollees_Id` INT(11) NOT NULL PRIMARY KEY, `Enrollees_Name` VARCHAR(150) NOT NULL, `Activation_Status` VARCHAR(150) NOT NULL, `Birth_Date` VARCHAR(150) NOT NULL,`Phone` VARCHAR(150),`Dependent_Name` VARCHAR(150) )")
	db.Query("CREATE TABLE IF NOT EXISTS `Enrollees_Dependents` (`Dependent_Id` INT(11) NOT NULL PRIMARY KEY, `Dependent_Name` VARCHAR(150) NOT NULL, `Birth_Date` VARCHAR(150) NOT NULL)")
}

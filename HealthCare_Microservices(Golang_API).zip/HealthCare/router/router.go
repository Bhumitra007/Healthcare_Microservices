package router

import (
	"net/http"

	"../handlers"

	handler "../github.com/gorilla/handlers"
	mux "../github.com/gorilla/mux"
)

// InitServer provides the routes for the API and then starts the server
func InitServer() {
	router := mux.NewRouter()

	// Enrollee Table API
	router.HandleFunc("/api/v1.0/Create_Enrollee", handlers.CreateEnrollee).Methods("POST")   // Adding new enrollee
	router.HandleFunc("/api/v1.0/Update_Enrollee", handlers.UpdateEnrollee).Methods("PUT")    //Updating Enrollee
	router.HandleFunc("/api/v1.0/Delete_Enrollee", handlers.DeleteEnrollee).Methods("DELETE") //Delete Enrollee

	//Enrollee Dependent Table API
	router.HandleFunc("/api/v1.0/Create_Enrollee_Dependent", handlers.CreateEnrolleeDependent).Methods("POST")   // Adding new Dependent
	router.HandleFunc("/api/v1.0/Update_Enrollee_Dependent", handlers.UpdateEnrolleeDependent).Methods("PUT")    // Updatiing Dependent
	router.HandleFunc("/api/v1.0/Delete_Enrollee_Dependent", handlers.DeleteEnrolleeDependent).Methods("DELETE") // Delete Dependent

	// Starting server and handling CORS
	port := ":8080"
	http.ListenAndServe(port, handler.CORS(handler.AllowedHeaders([]string{"X-Requested-With", "Content-Type", "Authorization"}), handler.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE"}), handler.AllowedOrigins([]string{"*"}))(router))
}

package madels

////////////////////////////////////////// CREATE ENROLLEE STRUCT /////////////////////////////////////////

//Create Enrollee Request Struct
type CreateEnrolleeRequestBody struct {
	ID               int      `json:"Enrollees_Id"`
	Name             string   `json:"Enrollees_Name"`
	ActivationStatus *bool    `json:"Activation_Status"` //for comparision of boolen value that's why use pointer
	Birthdate        string   `json:"Birth_Date"`
	Phone            string   `json:"Phone"`
	Dependent        []string `json:"Dependent_Name"`
}

//Create Enrollee Response Struct
type CreateEnrolleeResponseBody struct {
	Result string `json:"Result"`
}

////////////////////////////////////////// MODIFY ENROLLEE STRUCT /////////////////////////////////////////

type ModifyEnrolleeRequestBody struct {
	ID               int      `json:"Enrollees_Id"`
	Name             string   `json:"Enrollees_Name"`
	ActivationStatus bool     `json:"Activation_Status"`
	Birthdate        string   `json:"Birth_Date"`
	Phone            string   `json:"Phone"`
	Dependent        []string `json:"Dependent_Name"`
}

/////////////////////////////////////////  DELETE ENROLLEE STRUCT  ////////////////////////////////////////////

type DeleteEnrolleeRequestBody struct {
	ID int `json:"Enrollees_Id"`
}

///////////////////////////////////// CREATE ENROLLEE DEPENDENT STRUCT  /////////////////////////////////////////

//Create Enrollee Dependent Request Struct
type CreateEnrolleeDependentRequestBody struct {
	ID            int    `json:"Dependent_Id"`
	DependentName string `json:"Dependent_Name"`
	Birthdate     string `json:"Birth_Date"`
}

//Create Enrollee Dependent Response Struct
type CreateEnrolleeDependentResponseBody struct {
	Result string `json:"Result"`
}

///////////////////////////////////// MODIFY ENROLLEE DEPENDENT STRUCT  /////////////////////////////////////////

type ModifyEnrolleeDependentRequestBody struct {
	ID            int    `json:"Dependent_Id"`
	DependentName string `json:"Dependent_Name"`
	Birthdate     string `json:"Birth_Date"`
}

/////////////////////////////////////////  DELETE ENROLLEE DEPENDENT STRUCT  ////////////////////////////////////////////

type DeleteEnrolleeDependentRequestBody struct {
	ID int `json:"Dependent_Id"`
}

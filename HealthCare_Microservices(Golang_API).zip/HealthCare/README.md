# Microservice in Golang
This repo contains microservice for tracking the status of enrollees in a health care program by using Golang.

# Details about Files and Folders

1. main.go (file) - This is the main of this project and will help us to start the flow of Api's by using this command - go run main.go

2. github.com (folder) - This folder contains package for sql-driver and for gorilla mux and handlers.

3. handlers(folder) - This folder contains Handlers detials which are responsible for writing response headers and bodies.

4. models(folder)- Conatains struct for API's.

5. repository(folder)- Contains Database related details and its operations.

6. route(folder)- Contains route related details i.e. Api enpoints, port details, Methods.


/////////////////////////////////   Request Body Details for API's   ///////////////////////////

1. Add a new enrollee--> 
        Endpont - /api/v1.0/Create_Enrollee
        Method - POST
        Request Payload - 
                            {   
                                    "Enrollees_id":5,     (Required)
                                    "Enrollees_Name":"Norm kline", (Required)
                                    "Birth_Date":"26-09-1992", (Required)
                                    "Activation_status":true,   (Required)
                                    "Phone":"123445",   (optional)
                                    "Dependent_Name":["Eric","James","cowel"] (optional)
                            }
        Response payload - 
                            {
                                "Result": "Enrollee has been added sucessfully."
                            }

2. Modify an existing enrollee--> 
        Endpont - /api/v1.0/Update_Enrollee
        Method - PUT
        Request Payload - 
                            {   
                                    "Enrollees_id":5,     (Required)
                                    "Enrollees_Name":"Norm kline", (optional)
                                    "Birth_Date":"26-09-1992", (optional)
                                    "Activation_status":true,   (optional)
                                    "Phone":"123445",   (optional)
                                    "Dependent_Name":["Eric","James","cowel"] (optional)
                            }
        Response payload - 
                            {
                                "Result": "Enrollee details updated sucessfully."

                            }

3. Remove an enrollee entirely--> 
        Endpont - /api/v1.0/Delete_Enrollee
        Method - DELETE
        Request Payload - 
                            {   
                                    "Enrollees_id":5,     (Required)
                                    "Enrollees_Name":"Norm kline", (optional)
                                    "Birth_Date":"26-09-1992", (optional)
                                    "Activation_status":true,   (optional)
                                    "Phone":"123445",   (optional)
                                    "Dependent_Name":["Eric","James","cowel"] (optional)
                            }
        Response payload - 
                            {
                                "Result": "Enrollee deleted sucessfully."

                            }

4. Add dependents to an enrollee--> 
        Endpont - /api/v1.0/Create_Enrollee_Dependent
        Method - POST
        Request Payload - 
                             {   
                                "Dependent_Id":11, (Required)
                                "Dependent_Name":"Chales", (Required)
                                "Birth_Date":"25-09-1992"   (Required)
                            }
        Response payload - 
                            {
                                "Result": "Enrollee's Dependent added sucessfully."

                            }

5. Modify existing dependents-->
        Endpont - /api/v1.0/Update_Enrollee_Dependent
        Method - PUT
        Request Payload - 
                             {   
                                "Dependent_Id":11, (Required)
                                "Dependent_Name":"Chales", (optional)
                                "Birth_Date":"25-09-1992"   (optional)
                            }
        Response payload - 
                            {
                                "Result": "Dependent details updated sucessfully."

                            }


6. Remove dependents from an enrollee-->
        Endpont - /api/v1.0/Delete_Enrollee_Dependent
        Method - DELETE
        Request Payload - 
                             {   
                                "Dependent_Id":11, (Required)
                                "Dependent_Name":"Chales", (optional)
                                "Birth_Date":"25-09-1992"   (optional)
                            }
        Response payload - 
                            {
                                "Result": "Dependent deleted sucessfully."

                            }
